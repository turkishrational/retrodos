"DOS50.img" is a 1.44MB bootable floppy disk image.

It contains MSDOS 5.0 operating system files.

IO.SYS and MSDOS.SYS files (on the disk) are MSDOS 5.0 kernel files
and they are re-written (re-developed) by Erdogan Tan
in 2022.

Erdogan Tan - 08/12/2022
 