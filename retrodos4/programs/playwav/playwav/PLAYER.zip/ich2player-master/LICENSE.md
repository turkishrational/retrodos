# License terms of the source code in the file printhex.asm

The code in the file printhex.asm is based on code shared by Dirk Wolfgang
Glomp on StackOverflow at https://stackoverflow.com/a/22897576. since he shared
this code there in 2014, it is covered by the Creative Commons CC BY-SA 3.0
license. See also https://stackoverflow.com/help/licensing

# License terms of the initial ICHPLAYER source code

Quoting the relevant part in [the README file](README.txt):

> *It's free, do with it what you will. I don't particularly care.*<br/>
> *Feel free to contact me with questions and improvements.*

      \- Jeff Leyda, 2 September 2002<br/>
