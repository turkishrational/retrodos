#ifndef STRPREFIX_H
#define STRPREFIX_H (1)

// strpfx.h - definitions for string prefix routines

extern char* strprefix ( char* szTest, char* szFull );
extern char* striprefix ( char* szTest, char* szFull );

#endif // STRPREFIX_H
