/* version.h */
#define VERSION_H
#include "switch.h"	/* set up switch default values */
#define EM_MATH         ON
#include "interp.h"
