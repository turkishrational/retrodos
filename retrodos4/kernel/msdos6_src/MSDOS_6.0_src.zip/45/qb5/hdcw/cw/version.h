#define MEM_MGR far pascal
#define LIBC far cdecl
#define APPL near pascal
#define TEXT_MGR far pascal
#define COW far pascal
