/* File: dshstub.c - dumb shell stub routines for QBI */
#include "version.h"

