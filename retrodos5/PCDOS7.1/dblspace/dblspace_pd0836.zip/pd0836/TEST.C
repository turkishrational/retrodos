/***    TEST.C - Test IsDoubleSpaceDrive function.
 *
 *      Version 1.00.02 - 5 January 1993
 */
#include "drvinfo.h"
#include <stdio.h>

void cdecl main (int argc, char **argv)
{
    BYTE    dr;
    int     fSwapped;
    BYTE    drHost;
    int     seq;
    int     fDetails;

    fDetails = (argc>1);

    for (dr=0; dr<26; dr++) {
        printf("%c: ",dr+'A');

        if (IsDoubleSpaceDrive(dr,&fSwapped,&drHost,&seq)) {
            printf("Compressed");
            if (fSwapped)
                printf(" and Swapped from");
            else
                printf(" and Mounted from");
            printf(" %c:\\DBLSPACE.%03d\n",drHost+'A',seq);
        }
        else if (fSwapped)
            printf("Swapped with %c:\n",drHost+'A');
        else
            printf("Normal\n");

        if (fDetails) {
            printf("dr=%d, fSwap=%d, drHost=%d, seq=%d\n",
                dr,fSwapped,drHost,seq);
        }
    }
}
