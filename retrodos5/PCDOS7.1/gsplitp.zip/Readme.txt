GSplit 3 Portable - Readme
--------------------------

Description:
------------

Split your large files into a set of smaller files called pieces for easier distribution or backup. GSplit also creates a Self-Uniting program that automatically joins the piece files together to restore the original file. Finally GSplit includes advanced features for safely splitting your files in a snap.

Requires Microsoft Windows(R) 95 OS2, 98, ME, 2000 SP4, XP, 2003 Server, Vista or higher.

Version Reference: 3.0.1

GSplit 3 (and all related applications/documentation) is copyright � G.D.G Software 2006-2009. All Rights Reserved.


Usage:
------

Just unpack the archive to a folder. No installation is required, no changes are made to your system files or registry.

Note: GSplit saves its settings in a preference file named "gsplitpref.xml" in the same folder as GSplit.exe, and profiles in a subfolder named "Profiles".
These folders should not be write-protected, otherwise GSplit will store its settings in your Windows Application Data folder (see Uninstall below for further information).

Execute GSplit.exe to start GSplit and split your files.

If you want to join piece files that have no self-uniting program, use GUnite.

At any time, click Help or press F1 to open the documentation.

If you want to use GSplit in batch processing or as a daemon, take a look at the "Batch, Command Line Options" help topic.


Documentation and Change History:
---------------------------------

See the HTML Help file "GSplit.chm". It is also available in HTML format online at

http://www.gdgsoft.com/gsplit/help


Homepage:
---------

http://www.gdgsoft.com/gsplit


License and Disclaimer:
-----------------------

GSplit may be distributed and used freely, even for commercial use.
Although GSplit has been extensively tested, it comes with ABSOLUTELY NO WARRANTY.
Refer to the GSplit License Agreement in GSplit.chm for details.

Please report all problems or suggestions. Thanks.


Uninstall:
----------

Remove the folder that contains GSplit.

If this folder was write-protected, GSplit may have stored its preferences and profiles in a subfolder named "GSplit" which is located in the Windows Application Data folder.
Generally:
On XP/2000/2003: C:\Documents and Settings\[User Name]\Application Data\GSplit
On Vista/2008: C:\Users\[User Name]\appdata\roaming\GSplit
On W9x/Me: C:\WINDOWS\Application Data\GSplit

You can safely remove the files inside that folder if you do not want to keep your preferences for GSplit.


Support:
--------

You can get the latest version of GSplit as well as other G.D.G. Software products by going to our website at:
http://www.gdgsoft.com

You can also go to the GSplit forum to post your queries or read contributions from other users:
http://www.gdgsoft.com/forum

If you have questions, bugs or feedback regarding GSplit to report, you can contact us by e-mail:
gsplit@gdgsoft.com

or at http://www.gdgsoft.com/contact

Please indicate your full name, a valid E-Mail address, the version of GSplit you are using (and your computer configuration if this is a bug report).


Notes:
------

1) The shell extension is not included in the portable edition.
If you want to add GSplit to Windows Explorer, please use the full installer available at
http://www.gdgsoft.com/download/gsplit.aspx

2) Do not remove the preference file "gsplitpref.xml" from the folder where GSplit.exe is located if you want it to save its settings in that folder.

3) Files like languages or skins can be referenced with the [PATH] variable in the Environment Options. [PATH] points to the folder where GSplit.exe is located. Example: [PATH]Languages\English.gsl

4) All executable files were compressed with UPX 3.03 available at http://upx.sourceforge.net/ to make the distribution smaller.